var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var User = require('../models/user');
var fs = require('fs');
var multer = require('multer');
var upload = multer({
    dest: './public/uploads/',
});
var lin = '<li role="presentation"><a id="login" href="/users/login">Login</a></li>';
var lout = '<li role="presentation"><a id="logout" href="/users/Logout">Logout</a></li>';

var anon_users = 0;
var selects = [];
selects.push('<option value="Physics">'+'Physics'+'</option>');

var class_ = require('../models/class');
var message_ = require('../models/message');


/*
var Topic = require('../models/topic');

Topic.find({}, function(err, topics) {

  for(var i = 0; i <topics.length; i++) {
    console.log(topics[i].topic);
    //rooms.push(topics[i].topic);
    selects.push('<option value="'+topics[i].topic+'">'+topics[i].topic+'</option>');
  }


  });

*/
// Register
router.get('/register', function (req, res) {
    var cookie = req.cookies.userid;
  if (req.user || typeof cookie !== 'undefined' ) {
      res.render('register', { logout: lout,profile:'<li role="presentation"><a id="profile" href="/users/profile">'+req.cookies.username+'</a></li>'});

  }
  else {
      res.render('register', { login: lin});
  }

});


router.get('/updatepollfront', function (req, res) {


});


router.get('/findchat', function (req, res) {


  var cookie = req.cookies.userid;

  if (req.user || typeof cookie !== 'undefined' ) {
      res.render('find', { logout: lout,profile:'<li role="presentation"><a id="profile" href="/users/profile">'+req.cookies.username+'</a></li>',select:selects});

  }
  else {
      res.render('find', { login: lin,select:selects });
  }
});

router.post('/setandgo', function (req, res) {
//console.log(req.body.topics);
//User.setRoomByUsername(req.cookies.username,req.body.topics);
User.getUserById(req.cookies.userid, function(err, user) {
//console.log(user.aname);
res.render('multichat',{anon_input:'<input type="hidden" id="anon" value="'+user.aname+'">',user_input:'<input type="hidden" id="fname" value="'+user.fname+'">',class:'Physics', logout: lout,profile:'<li role="presentation"><a id="profile" href="/users/profile">'+req.cookies.username+'</a></li>'});
});

});


router.post('/setDescription', function (req, res) {
  console.log(req.body.ClassName);
  var query = {'classname':req.body.ClassName};
  var new_data = {'description': req.body.description_d}
  class_.findOneAndUpdate(query, new_data, {upsert:true}, function(err, doc){
      if (err) return res.send(500, { error: err });
      return res.send("succesfully saved");
  });
});

router.post('/getDescription', function (req, res) {
  class_.findOne({"classname": req.body.ClassName}, function(err, clas) {
    if (clas == null) {
      res.send("");
    }
    else {
        res.send(clas.description);
      }

    });

});

router.post('/getOverwrite', function (req, res) {
  User.getUserById(req.cookies.userid, function(err, user) {
var getOver = user.htmlmod;
res.json(getOver)


    });

});


// Login
router.get('/login', function (req, res) {
  var cookie = req.cookies.userid;
  console.log(cookie);
  if(  typeof cookie == 'undefined')  {
    res.render('login', { login: lin });
  }
  else {
    res.redirect('homepage2');
    alert("Log out first");
  }
});

// Register User
router.post('/register', function (req, res) {
  console.log(req.body);
    var name = req.body.firstname;
    var email = req.body.email;
    var username = req.body.username;
    var password = req.body.password;
    var password2 = req.body.password2;

    var newUser = new User({
        fname: name,
        aname: "anon"+anon_users,
        email: email,
        username: username,
        password: password,
        htmlmod:''
    });
anon_users = anon_users+1;
    User.createUser(newUser, function (err, user) {
        if (err) throw err;
        console.log(user);
    });



    res.redirect('/users/login');

});


router.post('/login',
  passport.authenticate('local', {
    failureRedirect: 'login',
    failureFlash:false
}),
  function (req, res) {

    var cookie = req.cookies.userid;
  if (cookie === undefined)
  {
    res.cookie('userid',  req.user.id, { maxAge: 2592000000 });  // Expires in one month
    res.cookie('username',  req.user.username, { maxAge: 2592000000 });  // Expires in one month
  }
  else
 {
   // yes, cookie was already present
   console.log('cookie exists', cookie);
 }


    console.log('GOING IN');
    res.redirect('/users/homepage2');
});


router.get('/logout', function (req, res) {
    req.logout();
    res.clearCookie('userid');
    res.clearCookie('username');
    res.redirect('/users/login');
});



router.get('/chat', isLoggedIn, function (req, res) {

      res.render('multichat', { logout: lout,profile:'<li role="presentation"><a id="profile" href="/users/profile">'+req.cookies.username+'</a></li>' });
});


router.get('/profile', isLoggedIn, function (req, res) {
    //console.log(req.session);
    res.render('profile', { logout: lout,profile:'<li role="presentation"><a id="profile" href="/users/profile">'+req.cookies.username+'</a></li>'});
});

router.get('/homepage2', isLoggedIn, function (req, res) {

  User.getUserById(req.cookies.userid, function(err, user) {
    //console.log(getPosts());
getPosts("homepage2",function(stuff){
console.log(stuff);
  res.render('homepage2', {messages:stuff,pname:req.cookies.username,profile_input:'<input type="hidden" id="profile" value="'+user.username+'">',anon_input:'<input type="hidden" id="anon" value="'+user.aname+'">',user_input:'<input type="hidden" id="fname" value="'+user.fname+'">'});
});

})

  //res.render('homepage2', { logout: lout,profile:'<li role="presentation"><a id="profile" href="/users/profile">'+req.cookies.username+'</a></li>' });
});


function getPosts(room,callback){

  message_.find({"class": { $ne: "whole_comment" },"room":room})
       .sort({'updatedAt': 'desc'})
       .exec(function(err,messages) {
         var acc = '';
         var i =0;
           //for(var i = 0; i <messages.length; i++) {
           //console.log(messages[i]);
           if(messages ==""){
             callback("");
           }
           else{
           (function getmessages(i) {
          createPost(messages[i].owner,messages[i].class, messages[i].message,messages[i].postid, messages[i].replyid,function(post){
            acc=acc+post;
            console.log("trying "+i);


              if(i==messages.length-1){
                console.log("done");
                callback(acc);
              }
              else{
                i = i+1;
                getmessages(i)
              }
          });


        })(i);
      }

          // }



       });
}


function createPost(username,class_tag, data, post_id, comment_id, callback){


      message_.find({"class":  "whole_comment","replyid":comment_id})
           .sort({'updatedAt': 'desc'})
           .exec(function(err,messages) {


              if(messages ==""){
                //console.log("NOTHING");

                   var post = '\
                       <div id="'+post_id+'" class="'+class_tag+'"><div class="user_post">'+ username + ':</div><div class=message_body>'+ data + '<div class="like_area" style="float:right;" ><a class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-thumbs-up"></span></a><span class="counter_post">counter</span></div>  </div>\
                        <div id="'+comment_id+'" class="comment_box">\
                         <div class="comment_output" >\
</div> <input class="comment_input" type="text" placeholder="comment here...">\
<button class=comment_button>Comment</button><br></div></div>\
                         ';
                         callback(post);
            }
            else{
                //console.log("SOMETHING");
              var comments = '';
              var post = '\
                  <div id="'+post_id+'" class="'+class_tag+'"><div class="user_post">'+ username + ':</div><div class=message_body>'+ data + '<div class="like_area" style="float:right;" ><a class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-thumbs-up"></span></a><span class="counter_post">counter</span></div>  </div>\
                   <div id="'+comment_id+'" class="comment_box">\
                    <div class="comment_output" >';
                for(var i = 0; i <messages.length; i++)
                {
                  comments= comments+'<div class="whole_comment" id="'+messages[i].options+'"><span class="user_comment">'+ messages[i].owner + '</span>: <span class="just_comment">' + messages[i].message + '<span class="like_area" style="float:right;"><a class="btn btn-xs btn-primary"><span class="glyphicon glyphicon-thumbs-up"></span></a><span class="counter_post">counter</span></span></span></div>';
                }
               post = post+comments+'</div> <input class="comment_input" type="text" placeholder="comment here..."><button class=comment_button>Comment</button><br></div></div>';

               callback(post);
            }



           });



}

router.get('/PHYS1800', isLoggedIn, function (req, res) {

  User.getUserById(req.cookies.userid, function(err, user) {
    //console.log(getPosts());
    getPosts("PHYS1800",function(stuff){
    console.log(stuff);
    res.render('PHYS1800', {messages:stuff,pname:req.cookies.username,profile_input:'<input type="hidden" id="profile" value="'+user.username+'">',anon_input:'<input type="hidden" id="anon" value="'+user.aname+'">',user_input:'<input type="hidden" id="fname" value="'+user.fname+'">'});
});

})

});

router.get('/WElCOME', isLoggedIn, function (req, res) {

  User.getUserById(req.cookies.userid, function(err, user) {
    //console.log(getPosts());
    getPosts("WElCOME",function(stuff){
    console.log(stuff);
    res.render('WElCOME', {messages:stuff,pname:req.cookies.username,profile_input:'<input type="hidden" id="profile" value="'+user.username+'">',anon_input:'<input type="hidden" id="anon" value="'+user.aname+'">',user_input:'<input type="hidden" id="fname" value="'+user.fname+'">'});
});

})
});

router.get('/PASSION', isLoggedIn, function (req, res) {

  User.getUserById(req.cookies.userid, function(err, user) {
    //console.log(getPosts());
    getPosts("PASSION",function(stuff){
    console.log(stuff);
    res.render('PASSION', {messages:stuff,pname:req.cookies.username,profile_input:'<input type="hidden" id="profile" value="'+user.username+'">',anon_input:'<input type="hidden" id="anon" value="'+user.aname+'">',user_input:'<input type="hidden" id="fname" value="'+user.fname+'">'});
});

})
});

router.get('/DEVELOPER', isLoggedIn, function (req, res) {

  User.getUserById(req.cookies.userid, function(err, user) {
    //console.log(getPosts());
    getPosts("DEVELOPER",function(stuff){
    console.log(stuff);
    res.render('DEVELOPER', {messages:stuff,pname:req.cookies.username,profile_input:'<input type="hidden" id="profile" value="'+user.username+'">',anon_input:'<input type="hidden" id="anon" value="'+user.aname+'">',user_input:'<input type="hidden" id="fname" value="'+user.fname+'">'});
});

})
});


function isLoggedIn(req, res, next) {
    //console.log(req.isAuthenticated());
     var cookie = req.cookies.userid;
     /*
    if (req.isAuthenticated()==true) {
        return next();
    }
    else if(req.isAuthenticated()==false){
      res.render('login', { login: lin });
    }
    else if(cookie === undefined){
      res.render('login', { login: lin });
    }
    else {
        return next();
    }
    */

   if(cookie === undefined){
      res.render('login', { login: lin });
    }
    else {
        return next();
    }
}


passport.use(new LocalStrategy(
    function (username, password, done) {
        User.getUserByUsername(username, function (err, user) {
            if (err) throw err;
            if (!user) {
                return done(null, false, { message: 'Unknown User' });
            }

            User.comparePassword(password, user.password, function (err, isMatch) {
                if (err) throw err;
                if (isMatch) {
                    return done(null, user);
                } else {
                    return done(null, false, { message: 'Invalid password' });
                }
            });
        });
    }));

passport.serializeUser(function (user, done) {
    done(null, user.id);
});

passport.deserializeUser(function (id, done) {
    User.getUserById(id, function (err, user) {
        done(err, user);
    });
});



module.exports = router;
